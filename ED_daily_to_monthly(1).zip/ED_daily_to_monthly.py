#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 14:43:40 2020

@author: lucy
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import dates
import seaborn as sns  #seaborn is a nice plotting library that sits on top of matplotlib
import matplotlib.style as style
style.use('ggplot')
from statsmodels.tsa.seasonal import seasonal_decompose
from forecast.baseline import Naive1, SNaive
from sklearn.metrics import mean_squared_error, mean_absolute_error
from statsmodels.tools.eval_measures import rmse
from statsmodels.graphics.tsaplots import plot_acf




def load_data():
    '''Loads csv file '''
    
    data = pd.read_csv('ed_daily_ts_train.csv', index_col='date', parse_dates=True) 
    #parse_dates=True lets pandas know the index is a date field
    data.index.freq='D' #frequency of data is daily. have to set this manually.
    return data


data = load_data()
month_mean_data = data.resample(rule='M').mean()


START_DATE='2009-04-30'
month_mean_data.index= pd.date_range(START_DATE, periods=len(month_mean_data), freq='MS')
    
    
def plot_func(data_list, x_label, y_label_list, title, key, nrows=1, ncols=1, fig_size=(12,10)):
    if nrows == 1:
        fig, ax = plt.subplots(1,1, sharex=True, figsize=fig_size)
        ax.plot(data_list)
        ax.set_ylabel(y_label_list)
        ax.set_xlabel(x_label)
        ax.set_title(title)
        ax.legend([key])
    else: 
        fig, ax = plt.subplots(nrows, ncols, figsize=fig_size)
        for i in range(nrows):
            ax[i].plot(data_list[i])
            ax[i].set_ylabel(y_label_list[i])
            ax[i].set_xlabel(x_label)
            ax[i].legend([key[i]])
        fig.suptitle(title) 
    return fig, ax 
    

# Plot of daily data vs. av daily data per month
data_list1=[data, month_mean_data]
y_label_list1=['Arrivals', 'Arrivals']
key1=['Arrivals', 'Arrivals']
daily_n_av_daily_plots = plot_func(data_list1, 'Date', y_label_list1, 'Daily ED arrivals and Av. daily ED arrivals per month', key1, 2, 1)



def ts_train_test_split(data, split_date):
    '''
    split time series into training and test data

    Parameters
    ----------
    data : pd.DataFrame - time series data.  Index expected as datatimeindex
    split_data :  the date on which to split the time series

    Returns
    -------
    tuple (len=2) 
    0. pandas.DataFrame - training dataset
    1. pandas.DataFrame - test dataset
    '''
    
    train = data.loc[data.index < split_date]
    test = data.loc[data.index >= split_date]
    return train, test

train, test = ts_train_test_split(month_mean_data, '2016-06-30')

train_plot = plot_func(train, 'date', 'arrivals', 'Av. daily ED arrivals- Train data', 'Train data', nrows=1, ncols=1, fig_size=(12,6))

# Seasonal decomposition
sd_result = seasonal_decompose(train, model= 'multiplicative')
data_list2=[sd_result.trend, sd_result.seasonal, sd_result.resid]
y_list2= ['Arrivals- Trend', 'Arrivals- Seasonality', 'Arrivals- Residual']
key2= ['Trend', 'Seasonality', 'Residuals']
plot_func(data_list2, 'date', y_list2, 'Seasonal decomposition of ED arrivals training data', key2, 3, 1, (14,10))



# Simple forecasting baseline -- Seasonal Naive Method 
#### Overlaps with seasonal decomp
HORIZON = 12
PERIOD = 12

snf = SNaive(period=PERIOD)
snf.fit(train)
insample_predictions = snf.fittedvalues
train = train['actual']
                  
ax = train.plot(figsize=(12,4))
insample_predictions.plot(ax=ax)
ax.set_title('Train data with predictions')
ax.set(xlabel='Date', ylabel='ED arrivals');
ax.legend(['Train', 'Predictions'])

# In-sample diagnostics - modelling residuals 
plot_func(snf.resid, 'date', 'actual minus predictions', 'Modelling Residuals- SNaive', 'residuals', fig_size=(12,8))


# CAN'T PLOT
#sns.distplot(snf.resid.dropna())

def mean_absolute_percentage_error(y_true, y_pred): 
    '''
    MAPE

    Parameters:
    --------
    y_true -- np.array actual observations from time series
    y_pred -- the predictions to evaluate

    Returns:
    -------
    float, scalar value representing the MAPE (0-100)
    '''
    #y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

# Measuring size of in-sample error
mse= mean_squared_error(y_true=train[PERIOD:], y_pred=insample_predictions[PERIOD:]) 
mae = mean_absolute_error(y_true=train[PERIOD:], y_pred=insample_predictions[PERIOD:])
root_mse_sn = rmse(x1=train[PERIOD:], x2=insample_predictions[PERIOD:])
mape_sn = mean_absolute_percentage_error(y_true=train[PERIOD:], y_pred=insample_predictions[PERIOD:])

# Second forecast baseline - Naive 
##### Overlaps with modelling residuals 
nf1 = Naive1()
nf1.fit(train)
nf1_fitted_values = nf1.fittedvalues

ax = train.plot(figsize=(12,4))
nf1_fitted_values.plot(ax=ax)
ax.set(xlabel='date', ylabel='arrivals');
ax.legend(['Train', 'Predictions'])

# plot naive residuals 
plot_func(nf1.resid, 'date', 'actual minus predictions', 'Modelling residuals- Naive', 'residuals')

# In-sample error 
root_mse_n= rmse(x1=train[1:], x2=nf1_fitted_values[1:])
mape_n= mean_absolute_percentage_error(y_true=train[1:], y_pred=nf1_fitted_values[1:])

# Naive error slightly smaller for both mse and mape => slightly better in-sample

# Choose which baseline to use
# Further split train data to get validation set- out-of-sample accuracy 
train, val = ts_train_test_split(train, '2015-07-01')

# create models and fit data
PERIOD = 12
nf1 = Naive1()
snf = SNaive(period=PERIOD)
nf1.fit(train)
snf.fit(train)


# predict 12 steps ahead
HORIZON = 12
nf1_preds = nf1.predict(horizon=HORIZON)
snf_preds = snf.predict(horizon=HORIZON)

#plot the model predictions and compare best fit
fig, axes = plt.subplots(1, 1, sharex=True, figsize=(12, 8))

axes.figsize = (12, 10)

axes.plot(val)
axes.plot(pd.Series(nf1_preds, index=val.index));
axes.plot(pd.Series(snf_preds, index=val.index));
axes.set(ylabel='Arrivals');
axes.legend(['validation', 'Naive1', 'SNaive']);

# Naive errors
mape_nval= mean_absolute_percentage_error(y_true=val, y_pred=nf1_preds) 
root_mse_nval= rmse(x1=val, x2=nf1_preds)

# Seasonal Naive errors
mape_snval= mean_absolute_percentage_error(y_true=val, y_pred=snf_preds)
root_mse_snval= rmse(x1=val, x2=snf_preds)

# mape and root_mse both smaller for naive method. Hence naive better out-of-sample as well and in-sample. 
# Use naive for baseline 




# Prediction intervals 
intervals = nf1.prediction_interval(horizon=HORIZON, levels=[0.8, 0.9])

#plot the model with 90% predictions intervals
fig, axes = plt.subplots(1, 1, sharex=True, figsize=(12, 8))
axes.figsize = (12, 10)
axes.plot(val)
axes.plot(pd.Series(nf1_preds, index=val.index));
axes.set(ylabel='Av. daily arrivals per month');
limits = pd.DataFrame(intervals[1], index=val.index, columns=['lower', 'upper'])
axes.fill_between(val.index, limits['lower'], limits['upper'], 
                  alpha=.1, 
                  label='90% PI')
axes.legend(['validation', 'Naive', '90% PI']);




#what prediction interval coverage have we actually achieved?
#will look at the 90% prediction intervals
# looking at whether actual observed value (val) is within the 90% PI
for h in range(2, HORIZON+1, 2):
    h_validation = val.iloc[:h].to_numpy()
    h_upper = limits['upper'][:h]
    h_lower = limits['lower'][:h]
    covered = ((h_validation > h_lower) & (h_validation < h_upper)).sum()
    coverage = covered / h
    print(f'h_{h}: {coverage}')



# ARIMA
    
plot_acf(train);
# taking difference reduces seasonality and trend
train_diff = train.diff(periods=1)
train_diff_plot = plot_func(train_diff, 'date', 'arrivals- first difference', 'Train data- first difference', 'first difference', fig_size=(12,6))

# log transform stabilises variance. 
train = np.log(train)
train_log_plot = plot_func(train, 'date', 'log(arrivals)', 'Train data- Log transformation', 'log transform', fig_size=(12,6))
